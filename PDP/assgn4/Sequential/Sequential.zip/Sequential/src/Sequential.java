import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;


public class Sequential {

	public static void main(String[] args) {

		int n = 10000000;
		long startTime = System.currentTimeMillis();
		GuassianRandomNumber g = new GuassianRandomNumber(n);
		ArrayList<Float> sort_array = new ArrayList<Float>();
		try {

			BufferedReader br = new BufferedReader(new FileReader("data/Random_number.txt"));
			PrintWriter bw = new PrintWriter(new FileWriter("output/output.txt"));
			String line;
			while((line = br.readLine()) != null){
				StringTokenizer tokenizer = new StringTokenizer(line); 
				while(tokenizer.hasMoreElements()){
					String s = tokenizer.nextToken();
					sort_array.add(Float.parseFloat(s));
				}
			}			
			Collections.sort(sort_array);
			for(int i=0;i<sort_array.size();i++){
				bw.printf("%f\n",sort_array.get(i));
			}
			bw.close();
			br.close();
			long endTime = System.currentTimeMillis();
			System.out.println("The time is: "+(endTime - startTime) + " Milliseconds");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}


	}

}
