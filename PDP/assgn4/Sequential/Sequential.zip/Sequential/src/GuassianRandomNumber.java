import java.util.Random;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.*;

public class GuassianRandomNumber {

	public static void randomNumberGeneratorNormal(float[] arr, int problemSize){

		float maxNum = (float) (problemSize * 10.0);
		float mean = (float) (maxNum/2.0);
		float var = (float) Math.sqrt(maxNum);
		Random rnd = new Random();

		for( int i = 0; i < problemSize; i++){
			arr[i] = (float) (mean + rnd.nextGaussian()*var);
		}
	}


	public GuassianRandomNumber(int n) {

		float[] arr = new float[n];
		randomNumberGeneratorNormal(arr, n);	
		String file = "data/Random_number.txt";
		PrintWriter out;
		try {
			out = new PrintWriter(file);
			for ( int i = 0; i < n; i++){
				out.printf("%f\t", arr[i]);
			}
			 out.close();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
}