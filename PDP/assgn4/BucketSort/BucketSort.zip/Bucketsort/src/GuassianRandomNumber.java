import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Random;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class GuassianRandomNumber {

	public static void randomNumberGeneratorNormal(float[] arr, int problemSize) {

		float maxNum = (float) (problemSize * 10.0);
		float mean = (float) (maxNum / 2.0);
		float var = (float) Math.sqrt(maxNum);
		Random rnd = new Random();

		for (int i = 0; i < problemSize; i++) {
			arr[i] = (float) (mean + rnd.nextGaussian() * var);
		}
	}

	public GuassianRandomNumber(int n) {

		float[] arr = new float[n];
		randomNumberGeneratorNormal(arr, n);
		Path path=new Path("README.txt");
		try {
			FileSystem file = FileSystem.get(new Configuration());
			PrintWriter out = new PrintWriter(new OutputStreamWriter(file.create(path,true)));
			for (int i = 0; i < n; i++) {
				out.printf("%f\t", arr[i]);
			}
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
